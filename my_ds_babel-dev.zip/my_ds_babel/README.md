# Welcome to My Ds Babel
***

## Task
Hi,in this project I had to convert sql database into csv content and repectevely csv to sql while using 2 python functions
## Description
I have called some important libraries like pandas, sqlite3 and csv and I've made 2 functions to convert.
and also used to_csv function to write to csv file from token information from sql database
## Installation
You can install it while writing ipython on to do terminal
## Usage
print the output from token 2 function
### The Core Team


<span><i>Made at <a href='https://qwasar.io'>Qwasar Silicon Valley</a></i></span>
<span><img alt='Qwasar Silicon Valley Logo' src='https://storage.googleapis.com/qwasar-public/qwasar-logo_50x50.png' width='20px'></span>
